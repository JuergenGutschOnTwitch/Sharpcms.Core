tinyMCE.addI18n('en.sharpcmschooser',{
    insertlink : 'Insert link',
    insertfilelink : 'Insert link to file',
    insertpicture : 'Insert picture'
});